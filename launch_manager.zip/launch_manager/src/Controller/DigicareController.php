<?php

/**
 * @file
 * Contains Drupal\launch_manager\Controller\LaunchController.
 */
namespace Drupal\digicare\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Url;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
/**
 * Provides route responses for the Example module.
 */
class DigicareController extends ControllerBase {
  
  /**
   * Returns a ajax callback.
   *
   * @return array
   *   A simple response.
   */
    public function ignore_all() {

    	   // Assemble the markup.
    $build = array(
      '#markup' => $this->t('<p>The Page example module provides two pages, "simple" and "arguments".</p><p>The @simple_link just returns a renderable array for display.</p><p>The @arguments_link takes two arguments and displays them, as in @arguments_url</p>',
        array(
          '@simple_link' => '--',
          '@arguments_link' => '--',
          '@arguments_url' => '--',
        )
      ),
    );

    return $build;
    	
    } 
}

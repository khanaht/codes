<?php

/**
 * @file
 * Contains Drupal\launch_manager\Form\DeliverablesForm.
 */

namespace Drupal\launch_manager\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Implements form controler
 */
class DeliverablesForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hpe_launch_deliverables_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get the launch node id from the URL
    $currentPath = \Drupal::service('path.current')->getPath();
    $pathArgs = explode('/', $currentPath);
    $launchNodeId = $pathArgs[2];
    $isEditPage = $pathArgs[4] === 'edit';

    $deliverables = getDeliverables($isEditPage, $launchNodeId);
    $launchNode = null;

    if($deliverables === false) {
      $form['error_message'] = [
        '#type' => 'markup',
        '#markup' => 'Could not find the given launch.'
      ];
      return $form;
    }

    $form['isEditPage'] = [
      '#type' => 'hidden',
      '#value' => $isEditPage
    ];

    $form['launchNodeId'] = [
      '#type' => 'hidden',
      '#value' => $launchNodeId
    ];

    if(!$isEditPage) {
      $launchNode = node_load($launchNodeId);

      $form['progress_bar'] = [
        '#type' => 'inline_template',
        '#template' => '{{ html|raw }}',
        '#context' => [
          'html' => '
            <div class="progress">
              <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 66%;">
                <span class="sr-only">66% Complete</span>
              </div>
            </div>
          '
        ]
      ];
    }
    if($isEditPage) {
      $form['deliverables'] = [
        '#type' => 'table',
        '#title' => '<h4>Deliverables</h4>',
        '#header' => [
          'Name',
          'Deliverable Type',
          'Final Due',
          'Final Owner',
          'Delete',
        ],
      ];
    }
    else {
      $form['deliverables'] = [
        '#type' => 'table',
        '#title' => '<h4>Deliverables</h4>',
        '#header' => [
          'Name',
          'Deliverable Type',
          'Final Due',
          'Final Owner',
        ],
      ];
    }

    $delivMetaData = [];

    $i = 0;
    foreach ($deliverables as $row) {
      $data = getFormRowData($isEditPage, $row, $launchNode);

      $delivMetaData['i'.$i] = [
        'nid' => $data['nid'],
        'deliverable_category' => $data['deliverable_category'],
        'deliverable_title' => $data['deliverable_title'],
      ];

      $form['deliverables']['i'.$i]['deliverable_title'] = [
        '#markup' => $data['deliverable_title'],
      ];

      $form['deliverables']['i'.$i]['deliverable_type'] = [
        '#markup' => $data['deliverable_type'],
      ];

      $form['deliverables']['i'.$i]['final_due'] = [
        '#type' => 'date',
        '#default_value' => $data['final_due'],
      ];

      $form['deliverables']['i'.$i]['final_owner'] = [
        '#type' => 'entity_autocomplete',
        '#target_type' => 'user',
        '#default_value' => $data['final_owner'],
      ];
      if($isEditPage) {
        $form['deliverables']['i'.$i]['should_delete'] = [
          '#type' => 'checkbox',
          '#default_value' => false,
        ];
      }

      $i++;
    }

    $form['numDeliverables'] = [
      '#type' => 'hidden',
      '#value' => $i
    ];

    $form['delivMetaData'] = [
      '#type' => 'hidden',
      '#value' => json_encode($delivMetaData),
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t(!$isEditPage ? 'Submit' : 'Update Deliverables'),
      '#attributes' => ['style' => ['float: right'], 'class' => ['btn-primary']],
    ];

    if($isEditPage) {

      $addDeliverablesURLString = Url::fromRoute(
        'launch_manager.add_launch_deliverables',
        ['launch' => $launchNodeId]
      )->toString();

      $form['add_deliverables_button'] = [
        '#type' => 'inline_template',
        '#template' => '{{ html|raw }}',
        '#context' => [
          'html' => '
            <a class="btn btn-success"
                style="float: right; margin-right: 15px;"
                href="'.$addDeliverablesURLString.'">Add Deliverables</a>'
        ]
      ];

    }

    return $form;
  }

 /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $v = $form_state->getValues();
    $deliverables = $v['deliverables'];
    $numDeliverables = $v['numDeliverables'];

    for ($i = 0; $i < $numDeliverables; $i++) {
      $deliv = $deliverables['i'.$i];

      if(!empty($deliv['final_due']) && !pit_helpers_isValidDateStr($deliv['final_due'])) {
        $form_state->setErrorByName('final_due', $this->t('You must select a Final Date.'));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $v = $form_state->getValues();
    $deliverables = $v['deliverables'];
    $numDeliverables = $v['numDeliverables'];
    $delivMetaData = json_decode($v['delivMetaData'], true);

    for ($i = 0; $i < $numDeliverables; $i++) {
      $deliverableNode = null;
      $dMeta = $delivMetaData['i'.$i];
      $dDeliv = $deliverables['i'.$i];
      $deliverableNid = $dMeta['nid'];

      foreach($dDeliv as &$field) {
        if(empty($field)) {
          $field = null;
        }
      }

      $deliverableData = [
        'nid' => $v['isEditPage'] ? $deliverableNid : null,
        'type' => 'pit_deliverable',
        'title' => $dMeta['deliverable_title'],
        'field_deliverable_parent' =>  $v['launchNodeId'],
        'field_deliverable_category' => $dMeta['deliverable_category'],
        // 'field_deliverable_draft_due' => $dDeliv['draft_due'],
        // 'field_deliverable_draft_owner' => $dDeliv['draft_owner'],
        // 'field_deliverable_draft_weeks' => -1,
        'field_deliverable_final_due' => $dDeliv['final_due'],
        'field_deliverable_final_owner' => $dDeliv['final_owner'],
        'field_deliverable_final_week' => -1,
        // 'field_deliverable_pmm_due' => $dDeliv['pmm_due'],
        // 'field_deliverable_pmm_owner' => $dDeliv['pmm_owner'],
        // 'field_deliverable_pmm_week' => -1,
      ];

      // If the user wanted to delete the deliverable, delete it
      if($v['isEditPage'] && $dDeliv['should_delete']) {
        entity_delete_multiple('node', [$deliverableNid]);
        continue;
      }

      if($v['isEditPage']) {
        // Update the deliverable properties
        $deliverableNode = node_load($deliverableNid);
        foreach($deliverableData as $key => $value) {
          $deliverableNode->{$key} = $value;
        }
      }
      else {
        // Create the new deliverable
        $deliverableNode = entity_create('node', $deliverableData);
      }

      $deliverableNode->save();
    }

    $updateMessage = $v['isEditPage'] ?
      'The launch deliverables have been successfully updated.' :
      'The launch and its deliverables have been successfully submitted.';
    drupal_set_message(t($updateMessage));

    $form_state->setRedirectUrl(
      Url::fromRoute('launch_manager.launch_overview_page', ['launch' => $v['launchNodeId']])
    );
  }

}

function getDeliverables($isEditPage, $launchNodeId) {
  $deliverables = false;

  if($isEditPage) {
    return pit_helpers_getDeliverablesByParentNid($launchNodeId);
  }

  return pit_helpers_getDeliverableCategories('launch');
}

function getFormRowData($isEditPage, &$row, &$launchNode = null) {
  $data = [];

  if($isEditPage) {
    $data['nid'] = $row->nid->value;
    $data['deliverable_category'] = $row->field_deliverable_category->target_id;
    $data['deliverable_title'] = $row->title->value;
    $data['draft_due'] = $row->field_deliverable_draft_due->value;
    $data['draft_owner'] = !empty($row->field_deliverable_draft_owner->target_id) ?
      user_load($row->field_deliverable_draft_owner->target_id) : null;
    $data['pmm_due'] = $row->field_deliverable_pmm_due->value;
    $data['pmm_owner'] = !empty($row->field_deliverable_pmm_owner->target_id) ?
      user_load($row->field_deliverable_pmm_owner->target_id) : null;
    $data['final_due'] = $row->field_deliverable_final_due->value;
    $data['final_owner'] = !empty($row->field_deliverable_final_owner->target_id) ?
      user_load($row->field_deliverable_final_owner->target_id) : null;
    $data['deliverable_type'] = pit_helpers_getDeliverableType($row);

  } else {
    // $row is a deliverable category here, and a deliverable when editing (block above)
    $numWeeksForFinal = $row->field_launch_final_weeks;
    $numWeeksForFinal = !empty($numWeeksForFinal) ? $numWeeksForFinal : 0;
    $data['nid'] = null;
    $data['deliverable_category'] = $row->nid;
    $data['deliverable_title'] = $row->title;
    $data['draft_due'] = null;
    $data['draft_owner'] = null;
    $data['pmm_due'] = null;
    $data['pmm_owner'] = null;
    $data['final_due'] = pit_helpers_subWeeksToDate($launchNode->field_launch_date->value, $numWeeksForFinal, 1);
    $data['final_owner'] = null;
    $data['deliverable_type'] = $row->deliverable_type;
  }

  return $data;
}

<?php

/**
 * @file
 * Contains Drupal\launch_manager\Form\AddDeliverablesForm.
 */

namespace Drupal\launch_manager\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

/**
 * Implements form controler
 */
class AddDeliverablesForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hpe_launch_add_deliverables_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get the launch node id from the URL
    $currentPath = \Drupal::service('path.current')->getPath();
    $pathArgs = explode('/', $currentPath);
    $launchNodeId = $pathArgs[2];

    $launchNode = node_load($launchNodeId);

    if(!$launchNode) {
      $form['error_message'] = [
        '#type' => 'markup',
        '#markup' => 'Could not find the given launch.'
      ];
      return $form;
    }

    $deliverables = pit_helpers_getDeliverableCategories('launch');

    $existingDeliverables = pit_helpers_getDeliverablesByParentNid($launchNodeId);

    $currentLaunchDeliverables = [];

    foreach($existingDeliverables as $row){
      $currentLaunchDeliverables[] = pit_helpers_getField($row, 'field_deliverable_category', 'target_id');
    }

    $form['deliverables'] = [
      '#type' => 'table',
      '#title' => '<h4>Deliverables</h4>',
      '#header' => [
        'Name',
        'Deliverable Type',
        'Final Due',
        'Final Owner',
        'Add',
      ],
    ];

    $delivMetaData = [];

    $i = 0;
    foreach ($deliverables as $row) {
      $data = getFormRowData($row, $launchNode);

      // Don't show if the launch already has this deliverable
      if(in_array($data['deliverable_category'], $currentLaunchDeliverables)){
        continue;
      }

      $delivMetaData['i'.$i] = [
        'deliverable_category' => $data['deliverable_category'],
        'deliverable_title' => $data['deliverable_title'],
      ];

      $form['deliverables']['i'.$i]['deliverable_title'] = [
        '#markup' => $data['deliverable_title'],
      ];

      $form['deliverables']['i'.$i]['deliverable_type'] = [
        '#markup' => $data['deliverable_type'],
      ];

      $form['deliverables']['i'.$i]['final_due'] = [
        '#type' => 'date',
        '#default_value' => $data['final_due'],
      ];

      $form['deliverables']['i'.$i]['final_owner'] = [
        '#type' => 'entity_autocomplete',
        '#target_type' => 'user',
        '#default_value' => $data['final_owner'],
      ];

      $form['deliverables']['i'.$i]['should_add'] = [
        '#type' => 'checkbox',
        '#default_value' => false,
      ];

      $i++;
    }

    $form['launchNodeId'] = [
      '#type' => 'hidden',
      '#value' => $launchNodeId
    ];

    $form['numDeliverables'] = [
      '#type' => 'hidden',
      '#value' => $i
    ];

    $form['delivMetaData'] = [
      '#type' => 'hidden',
      '#value' => json_encode($delivMetaData),
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add Deliverables'),
      '#attributes' => ['style' => ['float: right'], 'class' => ['btn-primary']],
    ];

    return $form;
  }

 /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    $v = $form_state->getValues();
    $deliverables = $v['deliverables'];
    $numDeliverables = $v['numDeliverables'];

    for ($i = 0; $i < $numDeliverables; $i++) {
      $deliv = $deliverables['i'.$i];

      if(!empty($deliv['final_due']) && !pit_helpers_isValidDateStr($deliv['final_due'])) {
        $form_state->setErrorByName('final_due', $this->t('You must select a Final Date.'));
      }

      if(!empty($deliv['final_owner']) && !is_numeric($deliv['final_owner'])) {
        $form_state->setErrorByName('final_owner', $this->t('You must select a Final Owner.'));
      }
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $v = $form_state->getValues();
    $deliverables = $v['deliverables'];
    $numDeliverables = $v['numDeliverables'];
    $delivMetaData = json_decode($v['delivMetaData'], true);

    for ($i = 0; $i < $numDeliverables; $i++) {
      $deliverableNode = null;
      $dMeta = $delivMetaData['i'.$i];
      $dDeliv = $deliverables['i'.$i];

      foreach($dDeliv as &$field) {
        if(empty($field)) {
          $field = null;
        }
      }

      // Skip this deliverable if the user didn't select it
      if(!$dDeliv['should_add']) {
        continue;
      }

      $deliverableData = [
        'nid' => null,
        'type' => 'pit_deliverable',
        'title' => $dMeta['deliverable_title'],
        'field_deliverable_parent' =>  $v['launchNodeId'],
        'field_deliverable_category' => $dMeta['deliverable_category'],
        // 'field_deliverable_draft_due' => $dDeliv['draft_due'],
        // 'field_deliverable_draft_owner' => $dDeliv['draft_owner'],
        // 'field_deliverable_draft_weeks' => -1,
        'field_deliverable_final_due' => $dDeliv['final_due'],
        'field_deliverable_final_owner' => $dDeliv['final_owner'],
        'field_deliverable_final_week' => -1,
        // 'field_deliverable_pmm_due' => $dDeliv['pmm_due'],
        // 'field_deliverable_pmm_owner' => $dDeliv['pmm_owner'],
        // 'field_deliverable_pmm_week' => -1,
      ];

      // Create the new deliverable
      $deliverableNode = entity_create('node', $deliverableData);

      $deliverableNode->save();
    }

    drupal_set_message(t('The new launch deliverables were successfully added.'));

    $form_state->setRedirectUrl(
      Url::fromRoute('launch_manager.edit_deliverables_form', ['launch' => $v['launchNodeId']])
    );
  }

}

function getFormRowData(&$row, &$launchNode = null) {
  $data = [];

  // $row is a deliverable category here
  $numWeeksForFinal = $row->field_launch_final_weeks;
  $numWeeksForFinal = !empty($numWeeksForFinal) ? $numWeeksForFinal : 0;

  $data['deliverable_category'] = $row->nid;
  $data['deliverable_title'] = $row->title;
  $data['draft_due'] = null;
  $data['draft_owner'] = '';
  $data['pmm_due'] = null;
  $data['pmm_owner'] = '';
  $data['final_due'] = pit_helpers_subWeeksToDate($launchNode->field_launch_date->value, $numWeeksForFinal, 1);
  $data['final_owner'] = '';
  $data['deliverable_type'] = $row->deliverable_type;

  return $data;
}

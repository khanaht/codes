(function($) {

    $(document).ready(function(){ 
        $('.popper').popover({
            placement: 'left',
            container: 'body',
            html: true,
            content: function () {
                return $(this).next('.popover').html();
            }
        });
    });

})(jQuery);
<?php

/**
 * @file
 * Contains Drupal\launch_manager\Controller\LaunchArchive.
 */

namespace Drupal\launch_manager\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;

class LaunchArchive extends ControllerBase {
    public function render() {
        $angularData = [];
        $sql = "SELECT * FROM pit_archive";

        $query = db_query($sql);

        if($query) {
            // kint($query->fetchObject());
            $i = 0;
            foreach($query as $row) {
                $angularData['launches'][$i]['LaunchGroup'] = $row->LaunchGroup;
                $angularData['launches'][$i]['LaunchName'] = $row->LaunchName;
                $angularData['launches'][$i]['BusinessUnit'] = $row->BusinessUnit;
                $angularData['launches'][$i]['ProductCategory'] = $row->ProductCategory;
                $angularData['launches'][$i]['CodeName'] = $row->CodeName;
                $angularData['launches'][$i]['Name'] = $row->Name;
                $i++;
            }
        }

        // $data = json_encode($angularData);

        // kint($data);
    
        return [
        '#theme' => 'launch_archive_page',
        '#angularData' => $angularData,
        ];
    }
}

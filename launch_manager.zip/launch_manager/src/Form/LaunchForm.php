<?php

/**
 * @file
 * Contains Drupal\launch_manager\Form\LaunchForm.
 */

namespace Drupal\launch_manager\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\file\Entity\File;

/**
 * Implements form controler
 */
class LaunchForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hpe_launch_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Determine if this is the new or edit page
    $currentPath = \Drupal::service('path.current')->getPath();
    $pathArgs = explode('/', $currentPath);
    $isEditPage = count($pathArgs) > 3 && $pathArgs[3] === 'edit';

    // Make Drupal load this page's javascript and css files
    $form['#attached']['library'][] = 'launch_manager/launch-form';

    $todaysDate = date('Y-m-d');
    $launchNodeId = null;
    $launchNode = null;
    $data = [];
    $disableDates=false;

    if($isEditPage) {
      $launchNodeId = $pathArgs[2];
      $launchNode = node_load($launchNodeId);
      $disableDates =  true;

      if(!$launchNode) {
        $form['error_message'] = [
          '#type' => 'markup',
          '#markup' => 'Could not find the given launch.'
        ];
        return $form;
      }

      $data['launch_status'] = $launchNode->field_launch_status->target_id;
      $data['launch_group'] = $launchNode->field_launch_group->target_id;
      $data['launch_name'] = $launchNode->title->value;
      $data['launch_description'] = $launchNode->field_launch_desciption->value;
      $data['launch_date'] = $launchNode->field_launch_date->value;
      $data['late_entry_date'] = $launchNode->field_launch_date_late->value;
      $data['sa_date'] = $launchNode->field_launch_date_sa->value;
      $data['launch_news'] = $launchNode->field_launch_news->value;
      $data['launch_image'] = !is_null($launchNode->field_launch_image->entity) ?
        [$launchNode->field_launch_image->entity->id()] : [];
    } else {
      $data['launch_status'] = '';
      $data['launch_group'] = '';
      $data['launch_name'] = '';
      $data['launch_description'] = '';
      $data['launch_date'] = '';
      $data['late_entry_date'] = '';
      $data['sa_date'] = '';
      $data['launch_news'] = '';
      $data['launch_image'] = null;

      $form['progress_bar'] = [
        '#type' => 'inline_template',
        '#template' => '{{ html|raw }}',
        '#context' => [
          'html' => '
            <div class="progress">
              <div class="progress-bar progress-bar-striped" role="progressbar" style="width: 33%;">
                <span class="sr-only">33% Complete</span>
              </div>
            </div>
          '
        ]
      ];
    }

    $form['isEditPage'] = [
      '#type' => 'hidden',
      '#value' => $isEditPage
    ];

    $form['launchNodeId'] = [
      '#type' => 'hidden',
      '#value' => $launchNodeId
    ];

    $form['launch_status'] = [
      '#type' => 'select',
      '#title' => $this->t('Launch Status'),
      '#options' => pit_helpers_getTaxonomyTermsAsOptionsArray('launch_status'),
      '#empty_option' => $this->t('- Select -'),
      '#default_value' => $data['launch_status'],
      '#prefix' => '<div class="row"><div class="col-lg-6">',
      "#required"=>true,
    ];

    $form['launch_group'] = [
      '#type' => 'select',
      '#title' => $this->t('Launch Group'),
      '#options' => pit_helpers_getTaxonomyTermsAsOptionsArray('launch_groups'),
      '#empty_option' => $this->t('- Select -'),
      '#default_value' => $data['launch_group'],
      "#required"=>true,
    ];

    $form['launch_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Launch Name'),
      '#default_value' => $data['launch_name'],
      '#required' => true,

    ];

    $form['launch_description'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Description'),
      '#default_value' => $data['launch_description'],
      '#required' => FALSE,
      '#suffix' => '</div><div class="col-lg-6">',
      '#required' => true,
    ];

    $form['launch_date'] = [
      '#type' => 'date',
      '#title' => $this->t('<div style="margin-bottom: 5px;">Launch Date &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>'),
      '#default_value' => $data['launch_date'],
      '#prefix' => '<div class="row"><div class="col-lg-6">',
      '#suffix' => '</div>',
      '#required' => true,
    ];

    // Save the original value because if the user changes it, we
    // need to recalculate the launch deliverable dates
    $form['launch_date_original'] = [
      '#type' => 'hidden',
      '#default_value' => $data['launch_date'],
    ];

    $form['late_entry_date'] = [
      '#type' => 'date',
      '#title' => $this->t('<div style="margin-bottom: 5px">Late Entry Date</div>'),
      '#default_value' => $data['late_entry_date'],
      '#prefix' => '<div class="col-lg-6">',
      '#suffix' => '</div>',
      '#required' => true,
    ];

    $form['sa_date'] = [
      '#type' => 'date',
      '#title' => $this->t('<div style="margin: 15px 0 5px 0;">SA Date &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</div>'),
      '#default_value' => $data['sa_date'],
      '#prefix' => '<div class="col-lg-6">',
      '#suffix' => '</div></div><hr />',
      '#required' => true,
    ];

    $form['clone_launch'] = [
      '#type' => 'select',
      '#title' => $this->t('Clone Launch Deliverables (Optional)'),
      '#options' => pit_helpers_getNodesByType('launch'),
      '#empty_option' => $this->t('- Select -'),
      '#prefix' => '<div class="row"><div class="col-lg-6">',
      '#suffix' => '</div></div></div></div><hr/>',
      '#required' => false,
      '#disabled' => $isEditPage,
    ];

    $form['launch_news'] = [
      '#type' => 'text_format',
      '#title' => $this->t('Launch News'),
      '#default_value' => $data['launch_news'],
      '#format'=> 'full_html',
      '#prefix' => '<div class="bottom3">',
      '#suffix' => '</div>',
      '#required' => true,
    ];

    $form['launch_image'] = [
      '#type' => 'managed_file',
      '#title' => $this->t('Image'),
      '#upload_location' => 'public://',
      '#default_value' => $data['launch_image'],
      '#description' => t('png gif jpg jpeg'),
      '#upload_validators' => [
      'file_validate_extensions' => ['png gif jpg jpeg']
      ]
    ];

    $form['actions'] = [
      '#type' => 'actions',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => t(!$isEditPage ? 'Create Launch and Continue' : 'Update Launch'),
      '#attributes' => ['style' => ['float: right'], 'class' => ['btn-primary']],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    if(empty($form_state->getValue('launch_status'))) {
      $form_state->setErrorByName('launch_status', $this->t('You must select a Launch Status.'));
    }

    if(empty($form_state->getValue('launch_group'))) {
      $form_state->setErrorByName('launch_group', $this->t('You must select a Launch Group.'));
    }

    if(empty($form_state->getValue('launch_name'))) {
      $form_state->setErrorByName('launch_name', $this->t('You must select a Launch Name.'));
    }

    if(empty($form_state->getValue('launch_description'))) {
      $form_state->setErrorByName('launch_description', $this->t('You must provide a Launch Description.'));
    }

    if(!pit_helpers_isValidDateStr($form_state->getValue('launch_date'))) {
      $form_state->setErrorByName('launch_date', $this->t('You must select a Launch Date.'));
    }

    if(!pit_helpers_isValidDateStr($form_state->getValue('late_entry_date'))) {
      $form_state->setErrorByName('late_entry_date', $this->t('You must select a Late Entry Date.'));
    }

    if(!pit_helpers_isValidDateStr($form_state->getValue('sa_date'))) {
      $form_state->setErrorByName('sa_date', $this->t('You must select a Sales Date.'));
    }

    if(empty($form_state->getValue('launch_news'))) {
      $form_state->setErrorByName('launch_news', $this->t('You must provide the Launch News.'));
    }

    $launchName = $form_state->getValue('launch_name');
    $launchNodeId = $form_state->getValue('launchNodeId'); // Null if new launch
    if(empty($launchNodeId)) $launchNodeId = -1;

    $query = db_query("
      SELECT nid
      FROM node_field_data
      WHERE type = 'launch'
      AND TRIM(title) = TRIM(:title)
      AND nid != :launchNid",
      [':title' => $launchName, ':launchNid' => $launchNodeId]
    );
 
    foreach ($query as $row) {
      $form_state->setErrorByName('launch_name', $this->t('Launch name already exists.'));
      break;
    }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $v = $form_state->getValues();

    $launchData = [
      'nid' => $v['isEditPage'] ? $v['launchNodeId'] : null,
      'type' => 'launch',
      'title' => $v['launch_name'],
      'field_launch_date_late' => $v['late_entry_date'],
      'field_launch_date' => $v['launch_date'],
      'field_launch_group' => $v['launch_group'],
      'field_launch_status' => $v['launch_status'],
      'field_launch_date_sa' => $v['sa_date'],
      'field_launch_desciption' => $v['launch_description'],
      'field_launch_news' => $v['launch_news'],
      'field_launch_image' => $v['launch_image'],
    ];

    $launchNode = null;
    $redirectRoute = null;
    $clonedLaunch = $v['clone_launch'];

    if($v['isEditPage']) {
      $launchNode = node_load($v['launchNodeId']);
      $redirectRoute = 'launch_manager.launch_overview_page';
      foreach($launchData as $key => $value) {
        $launchNode->{$key} = $value;
      }
    }
    else {
      $launchNode = entity_create('node', $launchData);
      $redirectRoute = 'launch_manager.new_deliverables_form';
    }

    $launchNode->save();

    if($v['isEditPage']) {
      $this->recalculateDeliverableDates($v);
      drupal_set_message(t('The launch has been successfully updated.'));
    }

    if(empty($clonedLaunch)) {
      $form_state->setRedirectUrl(
        Url::fromRoute($redirectRoute, ['launch' => $launchNode->id()])
      );
    } else {
      pit_helpers_cloneLaunchDeliverablesByParentNid($clonedLaunch, $launchNode);
      $form_state->setRedirectUrl(
        Url::fromRoute('launch_manager.edit_deliverables_form', ['launch' => $launchNode->id()])
      );
    }

  }

  private function recalculateDeliverableDates(&$v) {
    if($v['isEditPage'] && $v['launch_date'] != $v['launch_date_original']) {
      $launchDeliverables = pit_helpers_getDeliverablesByParentNid($v['launchNodeId']);
      foreach($launchDeliverables as $launchDeliv) {
        $delivCategory = node_load($launchDeliv->field_deliverable_category->target_id);
        $numWeeks = $delivCategory->field_launch_final_weeks->value;
        if(!empty($numWeeks)) {
          $launchDeliv->field_deliverable_final_due = pit_helpers_subWeeksToDate($v['launch_date'], $numWeeks, 1);
          $launchDeliv->save();
        }
      }
    }
  }

}

(function($) {

  var info = {};

  $(document).ready(applyDynamicFormLogic);

  function applyDynamicFormLogic() {
    // DOM elements which are referenced multiple times in this script
    info.launchDateField = $('#edit-launch-date');
    info.saDateField = $('#edit-sa-date');
    info.LateEntryDateField = $('#edit-late-entry-date');

    // Updates the SA & Late Entry date fields when Launch Date is changed
    info.launchDateField.change(autoAssignDateFields);
  }

  function autoAssignDateFields() {
    var launchDate = info.launchDateField.val();
    var r = /^(\d{4})\-(\d{1,2})\-(\d{1,2})$/;
    // Make sure valid date
    if(r.test(launchDate)) {
      
          var saDate = new Date(launchDate);
          var leDate = new Date(launchDate);
          // SA date should default to launch date minus 4 Mondays
          saDate.setDate(saDate.getDate() + ((7-saDate.getDay())%7+1)-28);
          // Late Entry Date should default to the Friday of week - 13 from launch date
          leDate.setDate(leDate.getDate() + ((5-leDate.getDay())%5+1)-92);
          var sdMonth =  saDate.getMonth() + 1;
          var leMonth =  leDate.getMonth() + 1;
          var sdDate = saDate.getDate();
          var laDate = leDate.getDate();
          var saFinalDate;
          var leFinalDate;
          saFinalDate = saDate.getFullYear().toString();
          leFinalDate = leDate.getFullYear().toString();
          if(sdMonth < 10){
          
              if(sdDate < 10){
              
                saFinalDate = saFinalDate +"-0"+sdMonth.toString()+"-0" + saDate.getDate().toString();
              }
              else{
              
                saFinalDate = saFinalDate +"-0"+sdMonth.toString()+"-" + saDate.getDate().toString();
              }
          }
          else {
            if(sdDate < 10){
              
                saFinalDate = saFinalDate +"-"+sdMonth.toString()+"-0" + saDate.getDate().toString();
              }
              else{
              
                saFinalDate = saFinalDate +"-"+sdMonth.toString()+"-" + saDate.getDate().toString();
              }
         
          }
          if(leMonth < 10){
          
              if(laDate < 10 ){
                  leFinalDate = leFinalDate +"-0"+leMonth.toString()+"-0" + leDate.getDate().toString();
              }
              else{
              
                leFinalDate = leFinalDate +"-0"+leMonth.toString()+"-" + leDate.getDate().toString();
              }
             
          }
          else{
             if(laDate < 10 ){
                  leFinalDate = leFinalDate +"-"+leMonth.toString()+"-0" + leDate.getDate().toString();
              }
              else{
              
                leFinalDate = leFinalDate +"-"+leMonth.toString()+"-" + leDate.getDate().toString();
              }
          
            // leFinalDate = leFinalDate +"-"+leMonth.toString()+"-" + leDate.getDate().toString();
          }
                
      
      info.saDateField.val(saFinalDate);
      info.LateEntryDateField.val( leFinalDate );
    }
  }

})(jQuery);

/**
 * @file   arhive-app.js
 *
 * @description Angular app for the Launch Archive page.
 */

'use strict';

angular.module('baseApp')
  .controller('HomeCtrl', ['$scope','config','DTDefaultOptions', 'DTOptionsBuilder',
    function ($scope, Config, DTDefaultOptions, DTOptionsBuilder) {
    	var lang = {
          "lengthMenu": 'Show <select>'+
          '<option value="10">10</option>'+
          '<option value="-1">All</option>'+
          '</select>',
        };
        $scope.dtOptions = DTOptionsBuilder.newOptions()
          .withOption('language', lang);
      $scope.launches = $scope.data.launches;
      DTDefaultOptions.setDisplayLength(Config.dataTypeDisplayLength);
    }
  ]);

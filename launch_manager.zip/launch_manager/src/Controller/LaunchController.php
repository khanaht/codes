<?php

/**
 * @file
 * Contains Drupal\launch_manager\Controller\LaunchController.
 */

namespace Drupal\launch_manager\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\Core\Site\Settings;

class LaunchController extends ControllerBase {

  public function renderDeliverablesForm($launch) {
    $delivForm = \Drupal::formBuilder()->getForm('Drupal\launch_manager\Form\DeliverablesForm');

    return [
      '#theme' => 'launch_deliverables_form',
      '#form' => $delivForm,
    ];
  }

  public function renderAddDeliverablesForm($launch) {
    $delivForm = \Drupal::formBuilder()->getForm('Drupal\launch_manager\Form\AddDeliverablesForm');

    return [
      '#theme' => 'launch_add_deliverables_form',
      '#form' => $delivForm,
    ];
  }

  public function renderOverviewPage($launch) {
    global $base_url;
    $AEM = Settings::get('aem');
    $ch = curl_init($AEM['url']['itg']);

      curl_setopt($ch, CURLOPT_NOBODY, true);
      curl_exec($ch);
      $retcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
      // $retcode >= 400 -> not found, $retcode = 200, found.
      curl_close($ch);
      
    if($retcode != '401') {
      print('<span class="down-banner">The connection between Beacon and Digital Asset Manager is experiencing issues. The ability to upload/download files is not possible at this time.</span>');
    }

    $launchNode = node_load($launch);
    $angularData = null;
    $userRoles = \Drupal::currentUser()->getRoles();

    if(!is_null($launchNode)) {
      // json_encode does not work on Drupal objects loaded from node_load, so
      // we have to serialize them to JSON using the Drupal serializer service
      // and then json_decode them into a php object which we can then pass to
      // the twig template...
      $serializer = \Drupal::service('serializer');
      $angularData = [];

      $deliverables = pit_helpers_getDeliverablesByParentNid_sort($launch);
 

      $angularData['deliverables'] = json_decode(
        $serializer->serialize($deliverables, 'json', ['plugin_id' => 'entity'])
      );

      foreach($angularData['deliverables'] as $row) {
        $deliverableNid = pit_helpers_setField($row, 'nid', 'value');
        pit_helpers_setField($row, 'title', 'value');
        pit_helpers_setField($row, 'field_deliverable_last_upload', 'value');
        pit_helpers_setField($row, 'field_deliverable_final_owner', 'target_id', 'pit_helpers_getUserDisplayName');
        $row->xfinal_owner_uid = pit_helpers_getField($row, 'field_deliverable_final_owner', 'target_id');
        pit_helpers_setField($row, 'field_deliverable_final_due', 'value');
        $row->xstatus = pit_helpers_getDeliverableStatus($row);
        $row->xtype = pit_helpers_getDeliverableType($row);
        //$am_last_modified_date = pit_helpers_getField($row, 'field_deliverable_last_modified', 'value');
        $row->xlast_modified_date = (!empty($am_last_modified_date) ? date('M d, Y', strtotime($am_last_modified_date)) : '');
        if (array_key_exists(0, $row->field_deliverable_completion_com)) {
        $row->xfield_deliverable_completion_com = $row->field_deliverable_completion_com[0]->value;
        }
      }
      pit_helpers_showAemDeliverableFiles($launchNode, $angularData['deliverables'], $userRoles);

      $launchNode->weeksToLaunch = pit_helpers_weeksToLaunch($launchNode->field_launch_date->value);

      pit_helpers_setField($launchNode, 'nid', 'value');
      pit_helpers_setField($launchNode, 'title', 'value');
      pit_helpers_setField($launchNode, 'field_launch_date', 'value');
      pit_helpers_setField($launchNode, 'field_launch_date_late', 'value');
      pit_helpers_setField($launchNode, 'field_launch_date_sa', 'value');
      pit_helpers_setField($launchNode, 'field_launch_desciption', 'value');
      pit_helpers_setField($launchNode, 'field_launch_status', 'target_id', 'pit_helpers_get_taxonomy_name');
      pit_helpers_setField($launchNode, 'field_launch_group', 'target_id', 'pit_helpers_get_taxonomy_name');
    }

    $user = \Drupal::currentUser();
    $userRoles = $user->getRoles();

    $angularData['user'] = [
      'roles' => $userRoles,
      'uid' => $user->id(),
      'email' => $user->getUsername()
    ];

    return [
      '#theme' => 'launch_overview_page',
      '#angularData' => $angularData,
      '#launchNode' => $launchNode,
      '#userRoles' => $userRoles,
      '#baseUrl' => $base_url,
    ];
  }

  public function getLaunchDate($nid) {
    $query = "SELECT field_launch_date_value FROM node__field_launch_date WHERE entity_id = $nid";

    $result = db_query($query);

    if($result) {
      foreach($result as $row) {
        return $row->value;
      }
    }
  }

}

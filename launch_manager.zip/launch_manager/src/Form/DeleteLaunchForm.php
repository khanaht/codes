<?php

/**
 * @file
 * Contains Drupal\launch_manager\Form\DeleteLaunchForm.
 */

namespace Drupal\launch_manager\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;

class DeleteLaunchForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'hpe_delete_launch_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // Get the launch's id from the URL request
    $launchNid = \Drupal::request()->get('launch');
    $launchNode = node_load($launchNid);

    if(!$launchNode) {
      $form['error_message'] = [
        '#type' => 'markup',
        '#markup' => 'Could not find the given launch.'
      ];
      return $form;
    }

    $form['launchNid'] = [
      '#type' => 'hidden',
      '#value' => $launchNid
    ];

    $form['message'] = [
      '#type' => 'markup',
      '#markup' => '<p>Are you sure you want to delete the <b>' .
        $launchNode->title->value . '</b> launch?</p>',
    ];

    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => t('Delete Launch'),
      '#attributes' => ['style' => ['float: right'], 'class' => ['btn-danger']],
    ];

    $editLaunchUrlString = Url::fromRoute(
      'launch_manager.launch_overview_page', ['launch' => $launchNid]
    )->toString();

    $form['cancel_button'] = [
      '#type' => 'inline_template',
      '#template' => '{{ html|raw }}',
      '#context' => [
        'html' => '
          <a class="btn btn-secondary"
              style="float: right; margin-right: 15px;"
              href="'.$editLaunchUrlString.'">Cancel</a>'
      ]
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $v = $form_state->getValues();
    $launchNid = $v['launchNid'];

    $deliverablesQuery = db_query("
      SELECT deliverable.nid
      FROM node_field_data deliverable
      JOIN node__field_deliverable_parent parent ON deliverable.nid = parent.entity_id
      WHERE deliverable.type = 'pit_deliverable'
      AND parent.field_deliverable_parent_target_id = :launchNid
      ", [':launchNid' => $launchNid]
    );

    $deliverablesNids = [];

    foreach ($deliverablesQuery as $row) {
      $deliverablesNids[] = $row->nid;
    }

    // Delete the launch's deliverables first
    entity_delete_multiple('node', $deliverablesNids);

    // Delete the launch itself
    entity_delete_multiple('node', [intval($launchNid)]);

    // Let this user know everything was successfull
    drupal_set_message(t('The launch was succesfully removed.'));

    // Redirect back to the home page
    $form_state->setRedirectUrl(Url::fromUri('internal:/'));
  }

}

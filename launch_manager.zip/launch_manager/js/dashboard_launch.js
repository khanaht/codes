(function($) {

	$(document).ready(function(){ 
		// On click every plus sign the row class is added and removed.
		$("#data_view").on( "click"," .row-class i", function() {

			var data_target = $( this ); 


			if(data_target.hasClass("fa-plus-square")) {

				data_target.removeClass("fa-plus-square");
				data_target.addClass("fa-minus-square"); 
			}else{
				data_target.removeClass("fa-minus-square");
				data_target.addClass("fa-plus-square"); 
			}

		});


		$("#data_view").on( "click"," .row-class i", function() {
			var  nid = $(this).parent().parent().parent().prev().attr('nid');
			var group_name = $(this).parent().parent().parent().prev().attr('group_name');
			var product_division = $(this).text();
			var tid  = $(this).parent().attr('tid');
			var row_id  = $(this).parent();
				$.ajax({ 
				type: 'GET', 
				url: '/product_page.json', 
				data: { field_launch_target_id:nid,field_launch_group_target_id:group_name,field_product_division_target_id:product_division}, 
				success: function (data) {
					var html_datatable = '<table class="table table-responsive" style="background-color: #eee; margin-left:25px;width:1225px;"><thead><tr><th>Product Name</th><th>Category</th><th style="display:none;">Status</th><th style="display: none;">Track</th><th>Copernicus Codes</th><th>PM Portal</th><th style="display: none;">Business Division</th><th>Product Managers</th></tr></thead><tbody>';
					$.each(data, function(key, val) {
						html_datatable = html_datatable + '<tr>';
						html_datatable = html_datatable + '<td>'+val.p_name+'</td>';
						html_datatable = html_datatable + '<td>'+val.p_category+'</td>';
						html_datatable = html_datatable + '<td>'+val.p_copernicus_code+'</td>';
						html_datatable = html_datatable + '<td></td>';
						html_datatable = html_datatable + '<td>'+val.p_product_managers+'</td>';
						html_datatable = html_datatable + '</tr>';

					});
					html_datatable = html_datatable + '</tbody></table>';

					row_id.next().html('<div style ="padding-left:40px">'+html_datatable+'</div>')

				}
			});

			return false;


		});

		$("tr td[data-row]").on( "click", function() {

			var data_target = $( this ).attr("data-target");  

			var loop_index = $( this ).attr("loop_index");

			var nid = $("tr[launch-row-list=row-"+loop_index+"] .launch_title").attr('nid');

			var group_name = $("tr[launch-row-list=row-"+loop_index+"] .launch_group a").text();



			$("tr[launch-row-list=row-"+loop_index+"]").attr('nid',nid);
			$("tr[launch-row-list=row-"+loop_index+"]").attr('group_name',group_name);

			$.ajax({ 
				type: 'GET', 
				url: '/product_page.json', 
				data: { field_launch_target_id:nid,field_launch_group_target_id:group_name}, 
				success: function (data) {

					var table_data = [];
					$("#"+data_target+" td").html("");
					$( "#"+data_target ).toggle("slow");

					for(var k in data) {

						table_data[data[k].p_division_tid[0]] = data[k].p_division_name;

					}
					for(var k in table_data) {


						var plus = '<a href="#" uib-popover="Expands the list of products and deliverables associated with this launch." data-toggle="collapse" ><i class="fa fa-plus-square" aria-hidden="true">&nbsp;&nbsp;'; 

						$("#"+data_target+" td").append("<div tid = "+k+" class='row-class'><i class='fa fa-plus-square' aria-hidden='true'><span style = 'padding-left:15px;'> "+table_data[k]+"</span> </i></a></div><div id = 'row-id-"+k+"' row-third-level ='third-row-id-"+k+"' class='row-collapse'> </div>");

					}
				}
			});

			return false;
		});



	});

})(jQuery);